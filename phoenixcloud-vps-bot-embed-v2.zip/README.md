# PhoenixCloud VPS Bot 2.0

Discord prefix: `ph?`

The bot provisions LXD containers and presents command responses as PhoenixCloud embeds.

## Current image
Default LXD image:
`images:almalinux/9`

Change with `LXC_IMAGE` in `.env`.

## Create
`ph?create 24 4 80 @Will`

This means:
- 24 GB RAM
- 4 vCPU
- 80 GB disk
- @Will as owner

## Setup
```bash
npm install
cp .env.example .env
nano .env
npm start
```

Important: test the LXD image and disk quota support before production use. The default LXD network may provide private IPs only.

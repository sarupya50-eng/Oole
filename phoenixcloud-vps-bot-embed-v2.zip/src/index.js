require("dotenv").config();

const {
  Client, GatewayIntentBits, Partials, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle
} = require("discord.js");
const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");

const PREFIX = process.env.PREFIX || "ph?";
const IMAGE = process.env.LXC_IMAGE || "images:almalinux/9";
const PROFILE = process.env.LXC_PROFILE || "default";
const DATA_FILE = path.resolve(process.env.DATA_FILE || "./data.json");
const CONSOLE_TIMEOUT_MS = Number(process.env.CONSOLE_TIMEOUT_MS || 600000);
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID || "";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { vps: {}, shares: {} }; }
}
let db = loadDB();
function saveDB() { fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2)); }

function run(cmd, args, timeout=60000) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, {timeout, maxBuffer: 1024*1024}, (error, stdout, stderr) => {
      if (error) {
        error.stdout = stdout;
        error.stderr = stderr;
        return reject(error);
      }
      resolve((stdout || "").trim());
    });
  });
}

function embed(title, description="", type="info") {
  const colors = {success:0x22c55e, error:0xef4444, warn:0xf59e0b, info:0x3b82f6, purple:0x8b5cf6};
  return new EmbedBuilder()
    .setColor(colors[type] || colors.info)
    .setAuthor({name:"PHOENIXCLOUD • VPS MANAGEMENT"})
    .setTitle(title)
    .setDescription(description)
    .setFooter({text:"PhoenixCloud • Private VPS Management"})
    .setTimestamp();
}
function ok(title, desc) { return embed(`✅ ${title}`, desc, "success"); }
function fail(title, desc) { return embed(`❌ ${title}`, desc, "error"); }
function info(title, desc) { return embed(`◆ ${title}`, desc, "info"); }
function warn(title, desc) { return embed(`⚠ ${title}`, desc, "warn"); }

function usage(command, example) {
  return fail("Invalid Usage", `Use:\n\`${command}\`\n\nExample:\n\`${example}\``);
}
function isAdmin(message) {
  return Boolean(ADMIN_ROLE_ID && message.member?.roles?.cache?.has(ADMIN_ROLE_ID));
}
function mention(id) { return `<@${id}>`; }
function getVpsForUser(userId) {
  return Object.values(db.vps).find(v => v.ownerId === userId);
}
function getAccessible(userId) {
  const result = Object.values(db.vps).filter(v => v.ownerId === userId);
  for (const v of Object.values(db.vps)) {
    const shares = db.shares[v.id] || {};
    if (shares[userId]) result.push(v);
  }
  return [...new Map(result.map(v => [v.id,v])).values()];
}
function safeName() {
  return `phoenix-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
}
function vpsButtons(id) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vps:start:${id}`).setLabel("Start").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`vps:stop:${id}`).setLabel("Stop").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`vps:restart:${id}`).setLabel("Restart").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`vps:info:${id}`).setLabel("Info").setStyle(ButtonStyle.Secondary)
  );
}
function controlButtons(id) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vps:console:${id}`).setLabel("Console").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`vps:resources:${id}`).setLabel("Resources").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`vps:ip:${id}`).setLabel("IP").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`vps:uptime:${id}`).setLabel("Uptime").setStyle(ButtonStyle.Secondary)
  );
}

async function status(name) {
  try {
    const out = await run("lxc", ["list", name, "--format", "json"]);
    const arr = JSON.parse(out);
    return arr[0]?.status || "UNKNOWN";
  } catch { return "UNKNOWN"; }
}
async function ipOf(name) {
  try {
    const out = await run("lxc", ["list", name, "--format", "json"]);
    const arr = JSON.parse(out);
    const nets = arr[0]?.state?.network || {};
    for (const n of Object.values(nets)) {
      for (const a of (n.addresses || [])) {
        if (a.family === "inet" && a.address) return a.address;
      }
    }
    return "Not assigned";
  } catch { return "Unavailable"; }
}
async function createVps(ram, cpu, disk, ownerId) {
  const name = safeName();
  await run("lxc", ["init", IMAGE, name, "--profile", PROFILE], 120000);
  try {
    await run("lxc", ["config","set",name,"limits.memory",`${ram}GB`]);
    await run("lxc", ["config","set",name,"limits.cpu",String(cpu)]);
    await run("lxc", ["config","device","set",name,"root","size",`${disk}GB`]);
    await run("lxc", ["start",name], 120000);
  } catch (e) {
    try { await run("lxc", ["delete",name,"--force"]); } catch {}
    throw e;
  }
  const v = {id:name, name, ownerId, ram, cpu, disk, image:IMAGE, createdAt:new Date().toISOString(), suspended:false};
  db.vps[name] = v; saveDB();
  return v;
}
function canManage(userId, v) {
  if (v.ownerId === userId) return "owner";
  const share = db.shares[v.id]?.[userId];
  return share || null;
}
async function sendDm(user, payload) {
  try { return await user.send(payload); } catch { return null; }
}

client.once("clientReady", () => console.log(`PhoenixCloud bot online as ${client.user.tag}`));

client.on("messageCreate", async message => {
  if (message.author.bot || !message.content.startsWith(PREFIX)) return;
  const parts = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (parts.shift() || "").toLowerCase();
  const args = parts;

  try {
    if (cmd === "help") {
      const e = info("PhoenixCloud Commands",
`**VPS Management**
\`${PREFIX}create <RAM> <CPU> <DISK> @user\` — Create VPS
\`${PREFIX}delete @user\` — Delete VPS
\`${PREFIX}suspend @user\` — Suspend VPS
\`${PREFIX}unsuspend @user\` — Unsuspend VPS
\`${PREFIX}reinstall @user\` — Reinstall VPS
\`${PREFIX}list\` — List all VPS

**User Management**
\`${PREFIX}manage\` — Open your VPS panel
\`${PREFIX}status\` — VPS status
\`${PREFIX}info\` — VPS information
\`${PREFIX}resources\` — RAM / CPU resources
\`${PREFIX}ip\` — VPS IP
\`${PREFIX}uptime\` — VPS uptime
\`${PREFIX}console\` — Private console
\`${PREFIX}sshx\` — Private SSHX hook
\`${PREFIX}share @user\` — Share access
\`${PREFIX}shares\` — View shares
\`${PREFIX}unshare @user\` — Remove share`);
      return message.reply({embeds:[e]});
    }

    if (["create","delete","suspend","unsuspend","reinstall","list"].includes(cmd) && !isAdmin(message))
      return message.reply({embeds:[fail("Permission Denied","You need the PhoenixCloud admin role to use this command.")]});

    if (cmd === "create") {
      if (args.length < 4) return message.reply({embeds:[usage(`${PREFIX}create <RAM> <CPU> <DISK> @user`, `${PREFIX}create 24 4 80 @Will`)]});
      const ram=Number(args[0]), cpu=Number(args[1]), disk=Number(args[2]);
      const user = message.mentions.users.first();
      if (![ram,cpu,disk].every(Number.isFinite) || ram<1 || cpu<1 || disk<1 || !user)
        return message.reply({embeds:[fail("Invalid Specifications","RAM, CPU and Disk must be positive numbers, and you must mention the owner.")]});
      if (getVpsForUser(user.id))
        return message.reply({embeds:[fail("VPS Already Exists",`${mention(user.id)} already owns a VPS.`)]});
      const creating = embed("🟡 Creating VPS",`Provisioning your PhoenixCloud VPS...\n\n**Owner:** ${mention(user.id)}\n**RAM:** \`${ram} GB\`\n**CPU:** \`${cpu} vCore\`\n**Disk:** \`${disk} GB\`\n\nPlease wait...`,"warn");
      const msg = await message.reply({embeds:[creating]});
      try {
        const v = await createVps(ram,cpu,disk,user.id);
        const ip = await ipOf(v.name);
        const done = ok("VPS Created Successfully",`**VPS ID:** \`${v.name}\`\n**Owner:** ${mention(user.id)}\n**RAM:** \`${ram} GB\`\n**CPU:** \`${cpu} vCore\`\n**Disk:** \`${disk} GB\`\n**IP:** \`${ip}\`\n**Status:** 🟢 Running`);
        await msg.edit({embeds:[done],components:[vpsButtons(v.id),controlButtons(v.id)]});
      } catch(e) {
        await msg.edit({embeds:[fail("VPS Creation Failed",`\`${(e.stderr || e.message || "Unknown error").slice(0,900)}\``)]});
      }
      return;
    }

    if (cmd === "list") {
      const vals = Object.values(db.vps);
      if (!vals.length) return message.reply({embeds:[info("VPS List","No VPS instances are currently registered.")]});
      const lines = [];
      for (const v of vals.slice(0,25)) lines.push(`**${v.name}** • ${mention(v.ownerId)} • \`${await status(v.name)}\` • \`${v.ram}GB / ${v.cpu}vCPU / ${v.disk}GB\``);
      return message.reply({embeds:[info("PhoenixCloud VPS List",lines.join("\n"))]});
    }

    const mentioned = message.mentions.users.first();
    if (["delete","suspend","unsuspend","reinstall"].includes(cmd)) {
      if (!mentioned) return message.reply({embeds:[usage(`${PREFIX}${cmd} @user`,`${PREFIX}${cmd} @Will`)]});
      const v=getVpsForUser(mentioned.id);
      if (!v) return message.reply({embeds:[fail("VPS Not Found",`${mention(mentioned.id)} does not have a VPS.`)]});
      if (cmd==="delete") {
        await run("lxc",["delete",v.name,"--force"]);
        delete db.vps[v.id]; delete db.shares[v.id]; saveDB();
        return message.reply({embeds:[ok("VPS Deleted",`VPS \`${v.name}\` belonging to ${mention(mentioned.id)} has been deleted.`)]});
      }
      if (cmd==="suspend") {
        await run("lxc",["stop",v.name,"--force"]); v.suspended=true; saveDB();
        return message.reply({embeds:[ok("VPS Suspended",`${mention(mentioned.id)}'s VPS is now suspended.`)]});
      }
      if (cmd==="unsuspend") {
        v.suspended=false; await run("lxc",["start",v.name]); saveDB();
        return message.reply({embeds:[ok("VPS Unsuspended",`${mention(mentioned.id)}'s VPS is running again.`)]});
      }
      if (cmd==="reinstall") {
        const old=v.name; await run("lxc",["delete",old,"--force"]);
        await run("lxc",["init",IMAGE,old,"--profile",PROFILE]);
        await run("lxc",["config","set",old,"limits.memory",`${v.ram}GB`]);
        await run("lxc",["config","set",old,"limits.cpu",String(v.cpu)]);
        await run("lxc",["config","device","set",old,"root","size",`${v.disk}GB`]);
        await run("lxc",["start",old]);
        v.createdAt=new Date().toISOString(); v.suspended=false; saveDB();
        return message.reply({embeds:[ok("VPS Reinstalled",`Reinstalled \`${old}\` using \`${IMAGE}\`.\n\n**RAM:** ${v.ram} GB\n**CPU:** ${v.cpu} vCore\n**Disk:** ${v.disk} GB`)]});
      }
    }

    let v = getVpsForUser(message.author.id);
    if (!v) {
      const accessible=getAccessible(message.author.id);
      if (accessible.length) v=accessible[0];
    }
    if (!v && ["manage","status","info","resources","ip","uptime","console","sshx","shares"].includes(cmd))
      return message.reply({embeds:[fail("No VPS Found","You do not currently have an accessible PhoenixCloud VPS.")]});

    if (cmd==="manage") {
      const s=canManage(message.author.id,v);
      if (!s) return message.reply({embeds:[fail("Access Denied","You do not have access to this VPS.")]});
      return message.reply({embeds:[info("VPS Management",`**VPS:** \`${v.name}\`\n**Owner:** ${mention(v.ownerId)}\n**Access:** \`${s === "owner" ? "Owner" : s}\`\n\nUse the controls below to manage your VPS.`)],components:[vpsButtons(v.id),controlButtons(v.id)]});
    }
    if (cmd==="status") return message.reply({embeds:[info("VPS Status",`**VPS:** \`${v.name}\`\n**Status:** \`${await status(v.name)}\``)]});
    if (cmd==="info") return message.reply({embeds:[info("VPS Information",`**VPS ID:** \`${v.name}\`\n**Owner:** ${mention(v.ownerId)}\n**RAM:** \`${v.ram} GB\`\n**CPU:** \`${v.cpu} vCore\`\n**Disk:** \`${v.disk} GB\`\n**Image:** \`${v.image}\`\n**Status:** \`${await status(v.name)}\``)]});
    if (cmd==="resources") {
      const out=await run("lxc",["exec",v.name,"--","sh","-lc","free -h; echo '---'; nproc"],30000);
      return message.reply({embeds:[info("VPS Resources",`\`\`\`\n${out.slice(0,3500)}\n\`\`\``)]});
    }
    if (cmd==="ip") return message.reply({embeds:[info("VPS Network",`**VPS:** \`${v.name}\`\n**IPv4:** \`${await ipOf(v.name)}\`\n\n*This is the LXD network address currently assigned to the container.*`)]});
    if (cmd==="uptime") {
      const out=await run("lxc",["exec",v.name,"--","uptime"],30000);
      return message.reply({embeds:[info("VPS Uptime",`\`${out}\``)]});
    }
    if (cmd==="shares") {
      const shares=db.shares[v.id] || {};
      const lines=Object.entries(shares).map(([id,p])=>`${mention(id)} • \`${p}\``);
      return message.reply({embeds:[info("VPS Shares",lines.length?lines.join("\n"):"No active shares.") ]});
    }
    if (cmd==="share") {
      if (!mentioned) return message.reply({embeds:[usage(`${PREFIX}share @user`,`${PREFIX}share @Friend`)]});
      if (mentioned.id===message.author.id) return message.reply({embeds:[fail("Invalid Share","You already own this VPS.")]});
      const vowner=getVpsForUser(message.author.id);
      if (!vowner) return message.reply({embeds:[fail("No VPS Found","You can only share a VPS you own.")]});
      db.shares[vowner.id] ||= {};
      db.shares[vowner.id][mentioned.id]="console"; saveDB();
      return message.reply({embeds:[ok("VPS Shared",`${mention(mentioned.id)} now has **Console** access to \`${vowner.name}\`.\n\nUse \`${PREFIX}shares\` to view access.`)]});
    }
    if (cmd==="unshare") {
      if (!mentioned) return message.reply({embeds:[usage(`${PREFIX}unshare @user`,`${PREFIX}unshare @Friend`)]});
      const vo=getVpsForUser(message.author.id);
      if (!vo) return message.reply({embeds:[fail("No VPS Found","You do not own a VPS.")]});
      if (!db.shares[vo.id]?.[mentioned.id]) return message.reply({embeds:[fail("Share Not Found","That user does not have access.")]});
      delete db.shares[vo.id][mentioned.id]; saveDB();
      return message.reply({embeds:[ok("Access Removed",`${mention(mentioned.id)} no longer has access to \`${vo.name}\`.`)]});
    }
    if (cmd==="console") {
      const s=canManage(message.author.id,v);
      if (!s) return message.reply({embeds:[fail("Access Denied","You do not have access to this VPS.")]});
      const dm=await sendDm(message.author,{embeds:[info("Private Console",`Console session for \`${v.name}\`.\n\nFor safety, this command uses a private DM and runs commands **inside the VPS container**, not on the host.\n\nReply with commands. Session expires after ${Math.round(CONSOLE_TIMEOUT_MS/60000)} minutes.`)]});
      if (!dm) return message.reply({embeds:[fail("DM Unavailable","I could not DM you. Enable DMs from this server, then try again.")]});
      return message.reply({embeds:[ok("Console Sent","I sent your private console session to your Discord DMs.")]});
    }
    if (cmd==="sshx") {
      return message.reply({embeds:[warn("SSHX Not Configured","The SSHX provider/hook is not configured yet. We will connect it after the VPS provisioning is tested. No SSHX URL is exposed publicly.")]});
    }

  } catch(e) {
    console.error(e);
    try { await message.reply({embeds:[fail("Unexpected Error",`\`${(e.message || "Unknown error").slice(0,900)}\``)]}); } catch {}
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;
  const [kind, action, id] = interaction.customId.split(":");
  if (kind !== "vps") return;
  const v=db.vps[id];
  if (!v) return interaction.reply({embeds:[fail("VPS Not Found","This VPS no longer exists.")],ephemeral:true});
  const access=canManage(interaction.user.id,v);
  if (!access) return interaction.reply({embeds:[fail("Access Denied","You do not have access to this VPS.")],ephemeral:true});
  if (["start","stop","restart"].includes(action) && access !== "owner" && access !== "full")
    return interaction.reply({embeds:[fail("Permission Denied","Your share permission does not allow power controls.")],ephemeral:true});
  try {
    if (action==="start") await run("lxc",["start",v.name]);
    if (action==="stop") await run("lxc",["stop",v.name,"--force"]);
    if (action==="restart") { await run("lxc",["restart",v.name]); }
    if (["start","stop","restart"].includes(action))
      return interaction.reply({embeds:[ok(`VPS ${action[0].toUpperCase()+action.slice(1)}`,`\`${v.name}\` is now \`${await status(v.name)}\`.`)]});
    if (action==="info")
      return interaction.reply({embeds:[info("VPS Information",`**VPS:** \`${v.name}\`\n**Owner:** ${mention(v.ownerId)}\n**RAM:** ${v.ram} GB\n**CPU:** ${v.cpu} vCore\n**Disk:** ${v.disk} GB\n**Status:** ${await status(v.name)}`)],ephemeral:true});
    if (action==="ip")
      return interaction.reply({embeds:[info("VPS IP",`\`${await ipOf(v.name)}\``)],ephemeral:true});
    if (action==="uptime") {
      const out=await run("lxc",["exec",v.name,"--","uptime"]);
      return interaction.reply({embeds:[info("VPS Uptime",`\`${out}\``)],ephemeral:true});
    }
    if (action==="resources") {
      const out=await run("lxc",["exec",v.name,"--","sh","-lc","free -h; echo '---'; nproc"]);
      return interaction.reply({embeds:[info("VPS Resources",`\`\`\`\n${out.slice(0,3000)}\n\`\`\``)],ephemeral:true});
    }
    if (action==="console") {
      const dm=await sendDm(interaction.user,{embeds:[info("Private Console",`Console session for \`${v.name}\`.\n\nUse \`${PREFIX}console\` in this DM to start a session. Direct command execution will be added after provisioning validation.`)]});
      return interaction.reply({embeds:[dm?ok("Console Sent","Check your Discord DMs."):fail("DM Unavailable","Enable DMs and try again.")],ephemeral:true});
    }
  } catch(e) {
    return interaction.reply({embeds:[fail("Action Failed",`\`${(e.stderr || e.message || "Unknown error").slice(0,900)}\``)],ephemeral:true});
  }
});

client.login(process.env.DISCORD_TOKEN);

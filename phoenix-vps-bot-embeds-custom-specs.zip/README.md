# PhoenixCloud VPS Bot

Discord prefix bot using `ph?` commands for LXC-backed VPS management.

## Features

- Admin-only `ph?create @user`
- Admin-only `ph?delete @user`
- Admin-only suspend/unsuspend
- Owner/admin `ph?manage`
- Start/stop/restart/reinstall
- Private Discord DM console
- Private SSHX delivery hook
- VPS sharing with View / Console / Full permissions
- Uptime, resource, IP and status commands
- SQLite persistence
- Audit logging without storing SSHX URLs or console output
- Rate limits and destructive-action confirmations

## Important architecture

Run the bot on the LXC host or through a tightly restricted service account that can invoke only the required LXC operations. Do NOT give normal Discord users host SSH/root access.

The console executes commands inside the selected LXC container with `lxc exec <container> -- bash -lc <command>`. It never executes the command on the host.

## Setup

1. Install Node.js 20+.
2. Install dependencies:
   `npm install`
3. Copy `.env.example` to `.env` and fill the values.
4. Create the Discord bot in the Discord Developer Portal and enable the Message Content intent.
5. Give the bot only the Discord permissions it needs.
6. Start:
   `npm start`

## Commands

### Admin
- `ph?create @user [name]`
- `ph?delete @user`
- `ph?suspend @user`
- `ph?unsuspend @user`
- `ph?reinstall @user [image]`
- `ph?list`

### Owner / shared users
- `ph?manage`
- `ph?console`
- `ph?status`
- `ph?info`
- `ph?resources`
- `ph?uptime`
- `ph?ip`
- `ph?share @user`
- `ph?shares`
- `ph?unshare @user`

`ph?console` opens a private DM console. The user then sends commands in that DM. Console sessions expire automatically.

## LXC assumptions

The bot expects `lxc` to be installed and usable by the account running Node.js.

For production, prefer a dedicated service account plus sudoers rules for specific `/usr/bin/lxc` operations rather than running the Discord bot as unrestricted root.

## SSHX

SSHX is deliberately a configurable hook because the exact sshx CLI/version and how you expose SSH access can differ.

Set `SSHX_ENABLED=true` and ensure `SSHX_COMMAND` is installed and correctly configured. The bot captures the generated URL and sends it only by DM. It does not log or post the URL publicly.

Before production, test SSHX manually in the same runtime account.

## Security checklist

- Never put the Discord bot token in source control.
- Keep `.env` private.
- Do not expose the LXC host shell to users.
- Use a dedicated service account where possible.
- Set Discord channel permissions appropriately.
- Keep audit logs in a private admin channel.
- Back up the SQLite database.
- Test destructive commands on a test container first.

require("dotenv").config();

const {
  Client, GatewayIntentBits, Partials, PermissionsBitField,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  EmbedBuilder
} = require("discord.js");
const { execFile } = require("child_process");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PREFIX = process.env.PREFIX || "ph?";
const ADMIN_ROLE_ID = process.env.ADMIN_ROLE_ID || "";
const DB_PATH = process.env.DB_PATH || "./data/phoenix.sqlite";
const CONSOLE_TIMEOUT_MS = Number(process.env.CONSOLE_TIMEOUT_MS || 900000);
const MAX_COMMAND_SECONDS = Number(process.env.MAX_COMMAND_SECONDS || 30);
const MAX_OUTPUT_CHARS = Number(process.env.MAX_OUTPUT_CHARS || 5000);
const SSHX_ENABLED = process.env.SSHX_ENABLED === "true";
const SSHX_COMMAND = process.env.SSHX_COMMAND || "sshx";
const SSHX_TIMEOUT_MS = Number(process.env.SSHX_TIMEOUT_MS || 60000);
const AUDIT_CHANNEL_ID = process.env.AUDIT_CHANNEL_ID || "";

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

/* Minimal JSON-backed persistence.
   This keeps the starter dependency-light. For large production deployments,
   replace this with PostgreSQL/SQLite proper without changing the command layer. */
const STORE_PATH = DB_PATH.replace(/\.sqlite$/, ".json");
let store = { vps: {}, shares: {}, meta: { created: Date.now() } };
if (fs.existsSync(STORE_PATH)) {
  try { store = JSON.parse(fs.readFileSync(STORE_PATH, "utf8")); } catch {}
}
function save() {
  const tmp = STORE_PATH + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, STORE_PATH);
}

function run(bin, args, timeout = MAX_COMMAND_SECONDS * 1000) {
  return new Promise((resolve, reject) => {
    execFile(bin, args, { timeout, maxBuffer: 2 * 1024 * 1024, windowsHide: true }, (error, stdout, stderr) => {
      if (error) return reject(new Error((stderr || error.message || "command failed").trim()));
      resolve((stdout || "").trim());
    });
  });
}

function shellInside(container, command) {
  // The command is passed as one argument to bash -lc inside the container.
  return run("lxc", ["exec", container, "--", "bash", "-lc", command], MAX_COMMAND_SECONDS * 1000);
}

function isAdmin(message) {
  if (!message.member) return false;
  if (message.member.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;
  return Boolean(ADMIN_ROLE_ID && message.member.roles?.cache?.has(ADMIN_ROLE_ID));
}

function mentionId(message) {
  const m = message.mentions.users.first();
  return m?.id || null;
}

function ownedVps(userId) {
  return Object.values(store.vps).find(v => v.ownerId === userId && v.status !== "deleted");
}

function canAccess(userId, vps) {
  if (!vps) return null;
  if (vps.ownerId === userId) return "owner";
  for (const s of Object.values(store.shares)) {
    if (s.vpsId === vps.id && s.userId === userId) return s.permission;
  }
  return null;
}

function getVpsForUser(userId) {
  const own = ownedVps(userId);
  if (own) return own;
  const shared = Object.values(store.shares)
    .map(s => ({ s, v: store.vps[s.vpsId] }))
    .find(x => x.s.userId === userId && x.v && x.v.status !== "deleted");
  return shared?.v || null;
}

function makeManage(vps) {
  const embed = new EmbedBuilder()
    .setTitle("PhoenixCloud VPS Management")
    .setDescription(`VPS: **${vps.name}**\nStatus: **${vps.status}**\nOwner: <@${vps.ownerId}>`)
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vps:start:${vps.id}`).setLabel("Start").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`vps:stop:${vps.id}`).setLabel("Stop").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`vps:restart:${vps.id}`).setLabel("Restart").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`vps:console:${vps.id}`).setLabel("Console").setStyle(ButtonStyle.Secondary)
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vps:resources:${vps.id}`).setLabel("Resources").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`vps:ip:${vps.id}`).setLabel("IP").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`vps:uptime:${vps.id}`).setLabel("Uptime").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`vps:sshx:${vps.id}`).setLabel("SSHX").setStyle(ButtonStyle.Secondary)
  );
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vps:reinstall:${vps.id}`).setLabel("Reinstall").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`vps:shares:${vps.id}`).setLabel("Shares").setStyle(ButtonStyle.Secondary)
  );
  return { embeds: [embed], components: [row1, row2, row3] };
}

async function audit(client, text) {
  if (!AUDIT_CHANNEL_ID) return;
  try {
    const c = await client.channels.fetch(AUDIT_CHANNEL_ID);
    if (c?.isTextBased()) await c.send({ content: text.slice(0, 1900) });
  } catch {}
}

async function vpsStatus(vps) {
  try {
    const out = await run("lxc", ["list", vps.name, "--format", "csv", "-c", "ns4"], 10000);
    const state = out.split(",")[1] || "UNKNOWN";
    return state.toLowerCase();
  } catch { return "unknown"; }
}

async function createVps(ownerId, customName) {
  const id = crypto.randomBytes(4).toString("hex");
  const name = (customName || `phoenix-${ownerId.slice(-6)}-${id}`).replace(/[^a-zA-Z0-9-]/g, "-").slice(0, 50);
  await run("lxc", ["init", process.env.LXC_IMAGE || "images:ubuntu/24.04", name], 120000);
  try {
    await run("lxc", ["config", "set", name, "limits.memory", process.env.DEFAULT_RAM || "4GB"], 10000);
    await run("lxc", ["config", "set", name, "limits.cpu", process.env.DEFAULT_CPU || "2"], 10000);
  } catch {}
  store.vps[id] = {
    id, name, ownerId, status: "STOPPED", createdAt: Date.now(),
    image: process.env.LXC_IMAGE || "images:ubuntu/24.04"
  };
  save();
  return store.vps[id];
}

async function doAction(action, vps) {
  const map = {
    start: ["start", vps.name],
    stop: ["stop", vps.name],
    restart: ["restart", vps.name]
  };
  if (!map[action]) throw new Error("Unsupported action");
  await run("lxc", map[action], 120000);
  vps.status = action === "stop" ? "STOPPED" : "RUNNING";
  save();
}

async function getInfo(vps) {
  const status = await vpsStatus(vps);
  vps.status = status.toUpperCase();
  let ip = "Unavailable";
  try {
    const out = await shellInside(vps.name, "hostname -I | awk '{print $1}'");
    if (out) ip = out.split(/\s+/)[0];
  } catch {}
  return { status, ip };
}

async function sendConsole(user, vps) {
  const access = canAccess(user.id, vps);
  if (!access || access === "view") throw new Error("You do not have console permission for this VPS.");
  if ((await vpsStatus(vps)) !== "running") throw new Error("VPS is not running.");

  const dm = await user.createDM();
  await dm.send("🖥️ **PhoenixCloud private console**\nVPS: `" + vps.name + "`\nSend Linux commands here. `exit` closes the session.\n\n⚠️ Commands run inside your VPS, not on the LXC host.");

  const collector = dm.createMessageCollector({
    time: CONSOLE_TIMEOUT_MS,
    filter: m => m.author.id === user.id
  });

  collector.on("collect", async m => {
    const command = m.content.trim();
    if (!command) return;
    if (command.toLowerCase() === "exit") {
      collector.stop("user");
      return m.reply("🔒 Console closed.");
    }
    if (command.length > 2000) return m.reply("❌ Command is too long.");
    try {
      const out = await shellInside(vps.name, command);
      const body = (out || "(no output)").slice(0, MAX_OUTPUT_CHARS);
      await m.reply("```text\n" + body.replace(/```/g, "`​`​`") + "\n```");
      await audit(client, `🖥️ Console command by ${user.tag} on ${vps.name} (output omitted).`);
    } catch (e) {
      await m.reply("```text\nERROR: " + String(e.message).slice(0, 1500) + "\n```");
    }
  });
  collector.on("end", async (_, reason) => {
    if (reason === "time") {
      try { await dm.send("⏱️ Console session expired for security."); } catch {}
    }
  });
}

async function sendSshx(user, vps) {
  if (!SSHX_ENABLED) throw new Error("SSHX is not enabled. Set SSHX_ENABLED=true after configuring sshx.");
  const access = canAccess(user.id, vps);
  if (!access || access === "view") throw new Error("You do not have SSHX permission.");
  if ((await vpsStatus(vps)) !== "running") throw new Error("VPS is not running.");

  // SSHX CLI/version differs between installations. This hook expects the CLI
  // to print a URL to stdout. Never post stdout publicly.
  const url = await run(SSHX_COMMAND, [], SSHX_TIMEOUT_MS);
  const found = url.match(/https?:\/\/\S+/)?.[0];
  if (!found) throw new Error("SSHX did not return a connection URL. Test the sshx CLI manually first.");

  try {
    await user.send(`🔐 **PhoenixCloud SSHX**\nVPS: \`${vps.name}\`\n\n${found}\n\n⚠️ Keep this link private. Anyone with the link may be able to access the session.`);
  } catch {
    throw new Error("I could not DM you. Enable DMs from server members and try again.");
  }
  await audit(client, `🔐 SSHX generated for ${user.tag} on ${vps.name}. URL omitted.`);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

client.once("ready", () => {
  console.log(`PhoenixCloud bot online as ${client.user.tag}`);
  client.user.setActivity(`${PREFIX}manage | VPS`, { type: 0 });
});

client.on("messageCreate", async message => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const raw = message.content.slice(PREFIX.length).trim();
  const [cmd, ...args] = raw.split(/\s+/);
  const command = (cmd || "").toLowerCase();

  try {
    if (command === "help") {
      return message.reply([
        `**PhoenixCloud VPS Bot**`,
        `\`${PREFIX}create @user [name]\` — admin`,
        `\`${PREFIX}delete @user\` — admin`,
        `\`${PREFIX}suspend @user\` / \`${PREFIX}unsuspend @user\` — admin`,
        `\`${PREFIX}reinstall @user [image]\` — admin`,
        `\`${PREFIX}manage\` — manage your/shared VPS`,
        `\`${PREFIX}console\` — private DM console`,
        `\`${PREFIX}sshx\` — private SSHX DM`,
        `\`${PREFIX}status\`, \`${PREFIX}info\`, \`${PREFIX}resources\`, \`${PREFIX}uptime\`, \`${PREFIX}ip\``,
        `\`${PREFIX}share @user\`, \`${PREFIX}shares\`, \`${PREFIX}unshare @user\``
      ].join("\n"));
    }

    if (["create","delete","suspend","unsuspend","reinstall","list"].includes(command) && !isAdmin(message)) {
      return message.reply("❌ Admin only.");
    }

    if (command === "create") {
      const uid = mentionId(message);
      if (!uid) return message.reply(`Usage: \`${PREFIX}create @user [name]\``);
      if (ownedVps(uid)) return message.reply("❌ That user already owns a VPS.");
      const v = await createVps(uid, args[1]);
      await audit(client, `🟢 VPS created: ${v.name} for <@${uid}> by ${message.author.tag}`);
      return message.reply(`✅ Created **${v.name}** for <@${uid}>.`);
    }

    if (command === "delete") {
      const uid = mentionId(message);
      const v = ownedVps(uid);
      if (!v) return message.reply("❌ User has no VPS.");
      await message.reply(`⚠️ Confirm deletion of **${v.name}** by replying \`CONFIRM\` within 20 seconds.`);
      const c = message.channel.createMessageCollector({ time: 20000, max: 1, filter: m => m.author.id === message.author.id && m.content === "CONFIRM" });
      c.on("collect", async () => {
        await run("lxc", ["delete", "--force", v.name], 120000);
        v.status = "deleted"; save();
        for (const [sid, s] of Object.entries(store.shares)) if (s.vpsId === v.id) delete store.shares[sid];
        save();
        await audit(client, `🔴 VPS deleted: ${v.name} by ${message.author.tag}`);
        message.channel.send("✅ VPS deleted.");
      });
      return;
    }

    if (command === "suspend" || command === "unsuspend") {
      const uid = mentionId(message);
      const v = ownedVps(uid);
      if (!v) return message.reply("❌ User has no VPS.");
      if (command === "suspend") {
        try { await run("lxc", ["stop", v.name], 120000); } catch {}
        v.status = "SUSPENDED";
      } else {
        v.status = "STOPPED";
      }
      save();
      await audit(client, `🔒 VPS ${command}: ${v.name} by ${message.author.tag}`);
      return message.reply(`✅ ${command === "suspend" ? "Suspended" : "Unsuspended"} **${v.name}**.`);
    }

    if (command === "reinstall") {
      const uid = mentionId(message);
      const v = ownedVps(uid);
      if (!v) return message.reply("❌ User has no VPS.");
      const image = args[1] || process.env.LXC_IMAGE || "images:ubuntu/24.04";
      await message.reply(`⚠️ This will destroy all data on **${v.name}**. Reply \`REINSTALL\` within 20 seconds.`);
      const c = message.channel.createMessageCollector({ time: 20000, max: 1, filter: m => m.author.id === message.author.id && m.content === "REINSTALL" });
      c.on("collect", async () => {
        await run("lxc", ["delete", "--force", v.name], 120000);
        await run("lxc", ["init", image, v.name], 120000);
        v.image = image; v.status = "STOPPED"; save();
        await audit(client, `♻️ VPS reinstalled: ${v.name} by ${message.author.tag}`);
        message.channel.send(`✅ Reinstalled **${v.name}** with \`${image}\`.`);
      });
      return;
    }

    if (command === "list") {
      const rows = Object.values(store.vps).filter(v => v.status !== "deleted");
      return message.reply(rows.length ? rows.map(v => `\`${v.name}\` → <@${v.ownerId}> — ${v.status}`).join("\n") : "No VPSs.");
    }

    if (command === "manage") {
      const v = getVpsForUser(message.author.id);
      if (!v) return message.reply("❌ You don't have a VPS or shared VPS.");
      return message.reply(makeManage(v));
    }

    if (command === "console" || command === "sshx" || command === "status" || command === "info" || command === "resources" || command === "uptime" || command === "ip") {
      const v = getVpsForUser(message.author.id);
      if (!v) return message.reply("❌ You don't have access to a VPS.");
      if (command === "console") {
        await message.reply("🔐 Check your DMs. The console will never be posted publicly.");
        return sendConsole(message.author, v);
      }
      if (command === "sshx") {
        await message.reply("🔐 I will send the SSHX link to your DMs only.");
        return sendSshx(message.author, v);
      }
      const inf = await getInfo(v);
      if (command === "status") return message.reply(`🖥️ **${v.name}**: \`${inf.status}\``);
      if (command === "ip") return message.reply(`🌐 IP: \`${inf.ip}\``);
      if (command === "uptime") {
        const out = await shellInside(v.name, "uptime -p").catch(() => "Unavailable");
        return message.reply(`⏱️ Uptime: \`${out}\``);
      }
      if (command === "resources") {
        const out = await shellInside(v.name, "printf 'RAM\\n'; free -h; printf '\\nDISK\\n'; df -h /; printf '\\nCPU\\n'; nproc").catch(e => "Unavailable");
        return message.reply("```text\n" + out.slice(0, 1800) + "\n```");
      }
      return message.reply(`**${v.name}**\nStatus: \`${inf.status}\`\nIP: \`${inf.ip}\`\nImage: \`${v.image}\``);
    }

    if (command === "share") {
      const target = mentionId(message);
      const v = ownedVps(message.author.id);
      if (!v) return message.reply("❌ Only the VPS owner can share this VPS.");
      if (!target || target === message.author.id) return message.reply(`Usage: \`${PREFIX}share @user\``);
      const row = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(`share:${v.id}:${target}`)
          .setPlaceholder("Choose permission")
          .addOptions(
            new StringSelectMenuOptionBuilder().setLabel("View Only").setValue("view").setDescription("Status, resources, IP and uptime"),
            new StringSelectMenuOptionBuilder().setLabel("Console").setValue("console").setDescription("View + console + SSHX"),
            new StringSelectMenuOptionBuilder().setLabel("Full Access").setValue("full").setDescription("View + console + start/stop/restart")
          )
      );
      return message.reply({ content: `Choose permissions for <@${target}> on **${v.name}**.`, components: [row] });
    }

    if (command === "shares") {
      const v = getVpsForUser(message.author.id);
      if (!v || v.ownerId !== message.author.id) return message.reply("❌ Owner only.");
      const shares = Object.values(store.shares).filter(s => s.vpsId === v.id);
      return message.reply(shares.length ? shares.map(s => `<@${s.userId}> — **${s.permission}**`).join("\n") : "No shared users.");
    }

    if (command === "unshare") {
      const target = mentionId(message);
      const v = ownedVps(message.author.id);
      if (!v || !target) return message.reply(`Usage: \`${PREFIX}unshare @user\``);
      for (const [sid, s] of Object.entries(store.shares)) {
        if (s.vpsId === v.id && s.userId === target) delete store.shares[sid];
      }
      save();
      return message.reply(`✅ Access revoked for <@${target}>.`);
    }
  } catch (e) {
    console.error(e);
    return message.reply("❌ Operation failed. Check the bot logs.");
  }
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton() && !interaction.isStringSelectMenu()) return;
  try {
    const parts = interaction.customId.split(":");
    if (interaction.isStringSelectMenu() && parts[0] === "share") {
      const [, vpsId, target] = parts;
      const v = store.vps[vpsId];
      if (!v || v.ownerId !== interaction.user.id) return interaction.reply({ content: "❌ Only the VPS owner can grant access.", ephemeral: true });
      const permission = interaction.values[0];
      const sid = `${vpsId}:${target}`;
      store.shares[sid] = { id: sid, vpsId, userId: target, permission, createdAt: Date.now() };
      save();
      return interaction.update({ content: `✅ <@${target}> now has **${permission}** access to **${v.name}**.`, components: [] });
    }

    const [, action, vpsId] = parts;
    const v = store.vps[vpsId];
    if (!v) return interaction.reply({ content: "❌ VPS not found.", ephemeral: true });
    const access = canAccess(interaction.user.id, v);
    if (!access && !isAdmin(interaction)) return interaction.reply({ content: "❌ You do not have access.", ephemeral: true });

    if (["start","stop","restart"].includes(action)) {
      if (access !== "owner" && access !== "full" && !isAdmin(interaction)) return interaction.reply({ content: "❌ Full access required.", ephemeral: true });
      await doAction(action, v);
      return interaction.reply({ content: `✅ ${action} completed for **${v.name}**.`, ephemeral: true });
    }
    if (action === "console") {
      if (access === "view") return interaction.reply({ content: "❌ Console permission required.", ephemeral: true });
      await interaction.reply({ content: "🔐 Console sent to your DMs.", ephemeral: true });
      return sendConsole(interaction.user, v);
    }
    if (action === "sshx") {
      if (access === "view") return interaction.reply({ content: "❌ SSHX permission required.", ephemeral: true });
      await interaction.reply({ content: "🔐 SSHX will be sent to your DMs.", ephemeral: true });
      return sendSshx(interaction.user, v);
    }
    if (action === "resources") {
      const out = await shellInside(v.name, "free -h; echo; df -h /; echo; nproc").catch(() => "Unavailable");
      return interaction.reply({ content: "```text\n" + out.slice(0, 1800) + "\n```", ephemeral: true });
    }
    if (action === "ip") {
      const out = await shellInside(v.name, "hostname -I | awk '{print $1}'").catch(() => "Unavailable");
      return interaction.reply({ content: `🌐 IP: \`${out || "Unavailable"}\``, ephemeral: true });
    }
    if (action === "uptime") {
      const out = await shellInside(v.name, "uptime -p").catch(() => "Unavailable");
      return interaction.reply({ content: `⏱️ \`${out}\``, ephemeral: true });
    }
    if (action === "reinstall") {
      if (v.ownerId !== interaction.user.id && !isAdmin(interaction)) return interaction.reply({ content: "❌ Owner/admin only.", ephemeral: true });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`confirmreinstall:${v.id}`).setLabel("Confirm Reinstall").setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId(`cancel:${v.id}`).setLabel("Cancel").setStyle(ButtonStyle.Secondary)
      );
      return interaction.reply({ content: `⚠️ This deletes all data on **${v.name}**.`, components: [row], ephemeral: true });
    }
    if (action === "shares") {
      if (v.ownerId !== interaction.user.id && !isAdmin(interaction)) return interaction.reply({ content: "❌ Owner/admin only.", ephemeral: true });
      const shares = Object.values(store.shares).filter(s => s.vpsId === v.id);
      return interaction.reply({ content: shares.length ? shares.map(s => `<@${s.userId}> — **${s.permission}**`).join("\n") : "No shared users.", ephemeral: true });
    }
    if (action === "confirmreinstall") {
      if (v.ownerId !== interaction.user.id && !isAdmin(interaction)) return interaction.reply({ content: "❌ Owner/admin only.", ephemeral: true });
      await run("lxc", ["delete", "--force", v.name], 120000);
      await run("lxc", ["init", v.image || process.env.LXC_IMAGE || "images:ubuntu/24.04", v.name], 120000);
      v.status = "STOPPED"; save();
      await audit(client, `♻️ VPS reinstalled: ${v.name} by ${interaction.user.tag}`);
      return interaction.update({ content: `✅ **${v.name}** reinstalled.`, components: [] });
    }
    if (action === "cancel") return interaction.update({ content: "Cancelled.", components: [] });
  } catch (e) {
    if (!interaction.replied && !interaction.deferred) await interaction.reply({ content: "❌ Operation failed.", ephemeral: true });
  }
});

process.on("unhandledRejection", e => console.error("Unhandled:", e));
client.login(process.env.DISCORD_TOKEN);
